# Way of Revival

Neste arquivo compactado, você encontrará duas versões (Não conseguimos juntá-las a tempo)
A primeira versão contém um estágio adicional incompleto.
A segunda versão contém efeitos de luz.
Algumas poucas diferenças existem entre as duas versões
Se divirta

Neste jogo, você controlará quatro animais com o poder de ressurreição. Use de seus sacríficos para encontrar o caminho adiante em cada fase.

O vermelho pula mais alto.
O azul tem uma lança para espetar objetos.
O amarelo tem uma tocha para incendiar objetos.
O rosa possui uma bomba, mas ele não sobreviverá após usá-la...

Aperte Z para usar suas habilidades
WASD/Setinhas controlam os personagems
Espaço permite saltar

Dicas:
O que pode quebrar um muro de tijolos?
O que pode destruir uma teia?
Barris vermelhos parecem ser inflamáveis...
Um suporte de madeira parece frágil o suficiente...
O que pode destruir os inimigos?